# BBD Agent Quick Guide

A mobile-friendly BBD agent reference site with HTML/CSS/JavaScript frontend and Node.js/Express backend.

## Run locally
1. Install Node.js.
2. Run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000`.

## Deploy free
Push these files to GitHub and deploy the repository as a Node Web Service on a free hosting tier such as Render when available.

Build command: `npm install`
Start command: `npm start`

The BBD Sathi button opens the supplied Google Sites URL and may require authorized Flipkart access.

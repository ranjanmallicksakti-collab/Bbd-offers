# BBD Agent Quick Guide – TBBD 2026

A simple searchable web guide for BBD customer concerns, agent guidance, YODA/Knowledge reference paths, and BBD Sathi access.

## Included
- HTML/CSS/JavaScript frontend
- Node.js + Express backend/static server
- Search by concern, keyword, or path
- Copy-path button
- BBD Sathi opens in a new browser tab
- Mobile responsive layout
- `/api/health` endpoint for deployment checks

## Run locally
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run:
   `npm install`
4. Start:
   `npm start`
5. Open:
   `http://localhost:3000`

## Hosting
This is a standard Node/Express project and can be deployed to a Node-compatible hosting service. Set the start command to `npm start`. The server automatically uses the hosting provider's `PORT` environment variable.

## Important access note
The BBD Sathi button opens the provided Google Sites URL in a new tab. If the Google Site is restricted to Flipkart/internal users, agents will still need the required Flipkart/Google access.

## Updating content
Edit `public/script.js` and update the `concerns` array. The BBD Sathi URL is stored in `BBD_SATHI_URL` at the top of the same file.

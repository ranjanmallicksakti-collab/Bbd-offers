const BBD_SATHI_URL = "https://sites.google.com/flipkart.com/bbdoffersassist/home?pli=1&authuser=0";

const concerns = [
  {
    id: 1,
    title: "Amount Debited – Order Not Confirmed",
    guidance: "If the amount is debited, guide the CX that the order will be confirmed within 2 hours. If it is not confirmed within 2 hours, a full refund will be initiated. As per the provided BBD guidance, the applicable refund will be issued in 5–7 days.",
    path: "Payment Knowledge Pill → Amount Debited Order Not Confirmed → Within 2 Hours",
    keywords: "amount debit debited order not confirmed refund payment 2 hours 5 7 days pending successful unsuccessful"
  },
  {
    id: 2,
    title: "Payment Fraud Detected",
    guidance: "Wait till 8 hours. Tagging should be Non-Order Payment. After 8 hours, follow the applicable blacklisted/escalation path.",
    path: "Payment → Payment Fraud Detected",
    keywords: "payment fraud detected non order payment 8 hours blacklisted escalation"
  },
  {
    id: 3,
    title: "Order on Hold",
    guidance: "Check the order status and follow the latest applicable YODA decision path before providing a resolution. Do not commit a resolution without validating the current path.",
    path: "Latest YODA path → Order on Hold",
    keywords: "order hold on hold yoda bbd order status"
  },
  {
    id: 4,
    title: "Unable to Place Order",
    guidance: "Check the exact error or reason why the CX is unable to place the order and guide the CX using the applicable YODA decision path.",
    path: "Product Processing Queries → Unable to Place Order",
    keywords: "unable place order order placing error product processing"
  },
  {
    id: 5,
    title: "Product Out of Stock",
    guidance: "Guide the CX to use the “Notify Me” option so they receive a notification once the product becomes available. Applicable offers can then be checked when the product is back in stock.",
    path: "Product Processing Queries → Unable to Place Order → Out of Stock",
    keywords: "out stock notify me product available offer"
  },
  {
    id: 6,
    title: "Product Not Available at Exact Location",
    guidance: "Guide the CX to try a nearby location, use a friend or family member’s location, or try purchasing from a different account where applicable.",
    path: "Product Processing Queries → Unable to Place Order → Product Not Available at Location",
    keywords: "location pincode exact location nearby friend family different account unavailable"
  },
  {
    id: 7,
    title: "Unable to Make Payment",
    guidance: "Check the exact payment details and error shown by the CX. Guide them accordingly. If payment is not completed, ask the CX to retry the payment or try making the payment through the Flipkart web browser.",
    path: "Payment Knowledge Pill → Payment Related Flow",
    keywords: "unable payment payment failed unsuccessful retry web browser payment error"
  },
  {
    id: 8,
    title: "Offers & Cashback",
    guidance: "Open BBD Sathi and verify the latest offer details. Also check YODA, Casper and the Products page before briefing or guiding the CX. Payment Knowledge Pills have been updated with TBBD 2026 payment-related FAQs.",
    path: "YODA → Notification → BBD Sathi",
    keywords: "offers cashback bbd sathi yoda casper products notification tbdd payment faq"
  }
];

const list = document.getElementById("concernList");
const details = document.getElementById("details");
const searchBox = document.getElementById("searchBox");

function displayConcerns(data) {
  list.innerHTML = "";
  if (!data.length) {
    list.innerHTML = '<div class="no-results">No matching concern found. Try another keyword.</div>';
    return;
  }

  data.forEach(item => {
    const div = document.createElement("div");
    div.className = "concern";
    div.dataset.id = item.id;
    div.innerHTML = `<h3><span class="num">${item.id}</span>${item.title}</h3>`;
    div.addEventListener("click", () => showDetails(item));
    list.appendChild(div);
  });
}

function showDetails(item) {
  document.querySelectorAll(".concern").forEach(x => x.classList.remove("active"));
  const selected = document.querySelector(`.concern[data-id="${item.id}"]`);
  if (selected) selected.classList.add("active");

  const sathiButton = item.id === 8
    ? `<a class="btn primary" href="${BBD_SATHI_URL}" target="_blank" rel="noopener noreferrer">🔗 Open BBD Sathi</a>`
    : "";

  details.innerHTML = `
    <h2>${item.id}. ${item.title}</h2>
    <div class="label">Agent Guidance</div>
    <div class="guidance"><p>${item.guidance}</p></div>
    <div class="label">YODA / Knowledge Reference Path</div>
    <div class="path"><div class="path-text">${item.path}</div></div>
    <div class="actions">
      <button class="btn secondary" type="button" onclick="copyText(${JSON.stringify(item.path)})">📋 Copy Path</button>
      ${sathiButton}
    </div>
    <div class="notice">⚠️ Always verify the latest YODA / BBD Sathi information before committing a resolution to the CX.</div>
  `;

  details.scrollIntoView({ behavior: "smooth", block: "start" });
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    alert("Path copied!");
  } catch (e) {
    alert("Copy is not available in this browser. Please copy the path manually.");
  }
}

function searchConcern() {
  const q = searchBox.value.trim().toLowerCase();
  const filtered = concerns.filter(item =>
    `${item.title} ${item.guidance} ${item.path} ${item.keywords}`.toLowerCase().includes(q)
  );
  displayConcerns(filtered);
}

searchBox.addEventListener("input", searchConcern);
displayConcerns(concerns);
